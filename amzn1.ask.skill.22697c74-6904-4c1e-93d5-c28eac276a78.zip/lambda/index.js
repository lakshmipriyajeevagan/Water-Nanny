const Alexa = require('ask-sdk-core');
const moment = require('moment-timezone');

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    handle(handlerInput) {
       // const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

       // const duration = sessionAttributes['duration'];
        
        const speechText = 'Welcome to Water Nanny. I can help you stay hydrated throughout the day! Would you like to set reminders to drink water?';
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};

const WaterReminderIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'WaterReminderIntent'
    },
    async handle(handlerInput) {
        let dur = handlerInput.requestEnvelope.request.intent.slots.duration.value;

        const reminderApiClient = handlerInput.serviceClientFactory.getReminderManagementServiceClient(),
            { permissions } = handlerInput.requestEnvelope.context.System.user 
            
        if (!permissions) {
            return handlerInput.responseBuilder
                .speak("You need to enable reminder permissions in the Alexa app so this skill can send you reminders to drink water. I just sent you a card to do this")
                .withAskForPermissionsConsentCard(['alexa::alerts:reminders:skill:readwrite'])
                .getResponse()
        }

        
        const currentDateTime = moment().tz('Asia/Kolkata') // get current date and time in IST.
        
        //reminder every 1 hour
        if(dur === 'PT1H'){
            const reminderRequest = {
              "requestTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
              "trigger": {
                  "type" : "SCHEDULED_ABSOLUTE",
                  "scheduledTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  "timeZoneId" : "Asia/Kolkata",
                  "recurrence" : {                     
                  "startDateTime": currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  // "endDateTime" : "2020-08-10T10:00:00.000", // specify the end date for the recurring reminder
                  "recurrenceRules" : [                                          
                      `FREQ=DAILY;BYHOUR=7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22;BYMINUTE=0;BYSECOND=0;INTERVAL=1;`
                  ]               
                }
              },
              "alertInfo": {
                  "spokenInfo": {
                      "content": [{
                          "locale": "en-IN", 
                          "text": "Time to drink water",
                          "ssml": '<speak><amazon:emotion name="excited" intensity="high">"Hey there! It\'s time to drink water."</amazon:emotion></speak>'
                      }]
                  }
              },
              "pushNotification" : {                            
                  "status" : "ENABLED"
              }
            }
          
            try {
                await reminderApiClient.createReminder(reminderRequest)
            } catch(error) {   // notify if any err
                console.log(`~~~ Error: ${error}`)
                return handlerInput.responseBuilder
                    .speak('There was an error scheduling your reminder. Please try again later.')
                    .getResponse();
              }
        }
        
     /*   //reminder every half hour
        if(dur === 'PT30M'){
            const reminderRequest = {
              "requestTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
              "trigger": {
                  "type" : "SCHEDULED_ABSOLUTE",
                  "scheduledTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  "timeZoneId" : "Asia/Kolkata",
                  "recurrence" : {                     
                  "startDateTime": currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  // "endDateTime" : "2020-08-10T10:00:00.000", // specify the end date for the recurring reminder
                  "recurrenceRules" : [                                          
                      `FREQ=DAILY;BYHOUR=7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22;BYMINUTE=30;BYSECOND=0;INTERVAL=1;`
                  ]               
                }
              },
              "alertInfo": {
                  "spokenInfo": {
                      "content": [{
                          "locale": "en-IN", 
                          "text": "Time to drink water",
                          "ssml": '<speak><amazon:emotion name="excited" intensity="high">”Hey there! It\'s time to drink water.”</amazon:emotion></speak>'
                      }]
                  }
              },
              "pushNotification" : {                            
                  "status" : "ENABLED"
              }
            }
        
            try {
                await reminderApiClient.createReminder(reminderRequest)
            } catch(error) {   // notify if any err
                console.log(`~~~ Error: ${error}`)
                return handlerInput.responseBuilder
                    .speak('There was an error scheduling your reminder. Please try again later.')
                    .getResponse();
              }
        } */
        
        //REMINDER EVERY 3 HOURS
        if(dur === 'PT3H'){
            const reminderRequest = {
              "requestTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
              "trigger": {
                  "type" : "SCHEDULED_ABSOLUTE",
                  "scheduledTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  "timeZoneId" : "Asia/Kolkata",
                  "recurrence" : {                     
                  "startDateTime": currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  // "endDateTime" : "2020-08-10T10:00:00.000", // specify the end date for the recurring reminder
                  "recurrenceRules" : [                                          
                      `FREQ=DAILY;BYHOUR=7,10,13,16,19,22;BYMINUTE=0;BYSECOND=0;INTERVAL=1;`
                  ]               
                }
              },
              "alertInfo": {
                  "spokenInfo": {
                      "content": [{
                          "locale": "en-IN", 
                          "text": "Time to drink water",
                          "ssml": '<speak><amazon:emotion name="excited" intensity="high">"Hey there! It\'s time to drink water.”</amazon:emotion></speak>'
                      }]
                  }
              },
              "pushNotification" : {                            
                  "status" : "ENABLED"
              }
            }
          
            try {
                await reminderApiClient.createReminder(reminderRequest)
            } catch(error) {   // notify if any err
                console.log(`~~~ Error: ${error}`)
                return handlerInput.responseBuilder
                    .speak('There was an error scheduling your reminder. Please try again later.')
                    .getResponse();
              }
        }
        
         //REMINDER EVERY 2 HOURS
        if(dur === 'PT2H'){
            const reminderRequest = {
              "requestTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
              "trigger": {
                  "type" : "SCHEDULED_ABSOLUTE",
                  "scheduledTime" : currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  "timeZoneId" : "Asia/Kolkata",
                  "recurrence" : {                     
                  "startDateTime": currentDateTime.format('YYYY-MM-DDTHH:mm:ss'),
                  // "endDateTime" : "2020-08-10T10:00:00.000", // specify the end date for the recurring reminder
                  "recurrenceRules" : [                                          
                      `FREQ=DAILY;BYHOUR=7,9,11,13,15,17,19,21;BYMINUTE=0;BYSECOND=0;INTERVAL=1;`
                  ]               
                }
              },
              "alertInfo": {
                  "spokenInfo": {
                      "content": [{
                          "locale": "en-IN", 
                          "text": "Time to drink water",
                          "ssml": '<speak><amazon:emotion name="excited" intensity="high">"Hey there! It\'s time to drink water."</amazon:emotion></speak>'
                      }]
                  }
              },
              "pushNotification" : {                            
                  "status" : "ENABLED"
              }
            }
          
            try {
                await reminderApiClient.createReminder(reminderRequest)
            } catch(error) {   // notify if any err
                console.log(`~~~ Error: ${error}`)
                return handlerInput.responseBuilder
                    .speak('There was an error scheduling your reminder. Please try again later.')
                    .getResponse();
              }
        }
        
        
        
        //notify for successful reminder creation
        const speechText = 'You successfully scheduled a daily reminder to drink water!';
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};

const ConnectionsResponseHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'Connections.Response'
            && handlerInput.requestEnvelope.request.name === "AskFor"
    },
    handle(handlerInput) {
        console.log('connectionsResponse handler')
        const { status, isCardThrown } = handlerInput.requestEnvelope.request.payload

        if (status === "DENIED" && !isCardThrown) {
            return handlerInput.responseBuilder
                .speak("Please go to the Alexa mobile app to grant reminders permissions.")
                .withAskForPermissionsConsentCard(['alexa::alerts:reminders:skill:readwrite'])
                .getResponse();    
        } else if (isCardThrown) {
            return handlerInput.responseBuilder
                .speak("Ok, no problem. When you are ready, please go to the Alexa mobile app to grant reminders permissions or launch the skill and I'll ask you again.")
                .getResponse();
        }
        const speechText = "Should I go ahead and schedule a daily water reminder?"
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};

const NoIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NoIntent'
    },
    handle(handlerInput) {
        const speechText = 'Alrighty, no problem. When you want me to set a reminder for you just holler.';
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
}

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speechText = "To use this skill, say open water nanny. Then confirm with the duration and a reminder will be scheduled so you can stay hydrated throughout the day!";

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
                || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speechText = 'Thanks for trying out water nanny. Goodbye!';
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = handlerInput.requestEnvelope.request.intent.name;
        const speechText = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.message}`);
        const speechText = `Sorry, I couldn't understand what you said. Please try again.`;

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};

// This handler acts as the entry point for your skill, routing all request and response
// payloads to the handlers above. Make sure any new handlers or interceptors you've
// defined are included below. The order matters - they're processed top to bottom.
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        WaterReminderIntentHandler,  // Register WaterReminderIntentHandler declared above.
        NoIntentHandler,             // Register NoIntentHandler for when the user declines to schdedule a reminder.
        ConnectionsResponseHandler, // Register ConnectionsResponseHandler to receive voice permissions response with state.
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler) // Make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers.
    .addErrorHandlers(ErrorHandler)
    /* 
        Add the API Client to our skill, so the skill has access to the RemindersManagementServiceClient which is used 
        to interact with the Reminders API.
    */
    .withApiClient(new Alexa.DefaultApiClient()) 
    .lambda();
